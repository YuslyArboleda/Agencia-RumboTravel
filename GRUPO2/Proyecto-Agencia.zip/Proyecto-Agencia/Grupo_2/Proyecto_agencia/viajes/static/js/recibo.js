$(document).ready(function () { 
    let NombreClienteInput = $("#NombreInput").val();
    let NombreClienteMostrar = document.getElementById("NombreCliente").textContent;

    NombreClienteInput.on('input', function(e) { 
        NombreClienteMostrar = NombreClienteInput;
    }); 
})