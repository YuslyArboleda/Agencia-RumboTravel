$(document).ready(function () { 
    $('#CajaTexto').on('input', function() {   /* Se establece una funcion para ingresar, y hacemos que se enfoque en la caja de texto, adentro llamamos a la funcion de buscardestino */
        buscarDestino();
    });

    $('#BotonBusqueda').on('click', function(e) {  /* Se establece una funcion click para que se enfoque en el boton de busqueda y hacemos que verifique si hay informacion ingresada o no */
        let Buscar = $('#CajaTexto')[0]; /* Creamos una variable con el nombre de buscar y hacemos que se enfoque en la caja de texto */
        let Buscador = $('#CajaTexto').val(); /* Creamos una variable con el nombre de buscador y hacemos que se enfoque en la caja de texto agarrando lo ingresado */
        if(!Buscar.checkValidity()) { /* Creamos una condicion que se enfoque en la variable buscar y verifique si hay informacion puesta o no, en caso de que no alla, salga un error */
            e.preventDefault();
            e.stopPropagation();
            Swal.fire({
                icon: "error",
                title: "Error...",
                text: "Porfavor ingresar un destino!",
              });     
            return;
        }else{ /* En caso de que si alla informacion, nos mandara a la pagina de buscar paquetes con el Destino que buscamos */
            console.log(Buscador);
            window.location.href = `buscar_paquetes?q=${Buscador}`; /* La pagina buscar paquetes viene de la vista, en donde estan almacenados las distintas respectivas rutas y sus funciones */
        }
    });

    function buscarDestino(){ /* Se establece una funcion de nombre buscarDestino */
        let destino = $("#CajaTexto").val().trim(); /* Se establece una variable de nombre destino, que se enfoque en la caja de texto y nos quite todos los espacios que se ingresen */
        if(destino.length > 0){ /* Se crea una condicion en donde se agarra el tamaño del destino y verifica si es mayor a 0, en caso de que sea cierto, se ejecuta el apartado de verdad */
            $.ajax({ /* El ajax se disparara cada vez de que se escriba un caracter */
                url: "destino", /* Se crea una variable de nombre url y le asignamos la ruta de destino que esta ubicada en la URLs */
                data: {q:destino}, /* Se crea una variable de nombre data y le asignamos un valor query de consulta y llamamos el destino que se alla ingresado */
                success: function(data){ /* Se crea una funcion en donde ocurra un evento en caso de que se haga la consulta  */
                    let result = $("#resultado"); /* Se crea una variable de nombre result, esta enfocandose en el div resultado ubicado en el index principal */
                    result.empty();
                    if(destino.length > 2){ /* Se hace una condicion donde agarre el tamaño del destino y verifique si es mayor de 2, en caso de que si, se ejecuta el apartado de verdad */
                        if(data.length){ /* Se hace una condicion donde agarre el tamaño de la consulta realizada para verificar si existe */
                         data.forEach((element)=>{ /* Se crea un ciclo foreach en donde a cada elemento encontrado de la consulta, se agrege a una lista */
                            result.append(` 
                                <ul class="list-group list_destino">
                                <li class="list-group-item listaDes">${element.destino}</li>
                                </ul>
                                `);
                         });   
                         $('.listaDes').on('click',function (e) { /* Se crea una funcion click para que a la hora de presionar un resultado de la lista, reemplaze la caja de texto por el valor seleccionado en la lista */
                            let selecion_destino = $(this).text(); /*  */
                             $('#CajaTexto').val(selecion_destino);
                             result.empty(); 
                            
                         });
                        }else{ /* En caso de que no exista, al div de nombre resultado se le agregara un div que diga el siguiente mensaje:  */
                            result.append("<div>No se encontró resultados</div>");
                        }
                    }else{ /* En caso de que el tamaño del destino no sea mayor a 2, al div de nombre resultado se le agregara un div que diga el siguiente mensaje: */
                        result.append("<div>Digite màs caracteres</div>");                    
                    }
                },
            });
        }else{ /* En caso de que el tamaño del destino no sea mayor a 0, el resultado se vaciara, estando como originalmente se establecio, vacio*/
            $("#resultado").empty();;
        }
    }
})

