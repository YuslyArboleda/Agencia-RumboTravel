$(document).ready(function () {
    // ----------------------------------------------------------------------
    // Creamos acumuladores para cada habitacion con el fin de ponerle un limite a las personas que se puedan adiccionar entre los infantes y niños
    let AcumuladorHabitacionSencilla = 0;
    let AcumuladorHabitacionDoble = 0;
    let AcumuladorHabitacionTriple = 0;
    // ----------------------------------------------------------------------
    // Establecemos un controlador para el boton de realizar la reserva asi impidendole
    // al usuario de abrir y cerrar repetidas veces la ventana de las adicciones una vez ya habra las adicciones
    // ----------------------------------------------------------------------
    let TotalNinos = 0;
    // ----------------------------------------------------------------------
    let TotalInfantes = 0;
    // ----------------------------------------------------------------------
    let cantidad_Habitaciones_Sencillas = 0;
    let cantidad_Habitaciones_Dobles = 0;
    let cantidad_Habitaciones_Triples = 0;
    // ----------------------------------------------------------------------
    let TotalAPagar = 0;

    // ----------------------------------------------------------------------
    // Se crea un conjunto de condiciones las cuales establezcan el precio base de la reserva haciendo sus respectivos calculos y leyendo el tipo de habitacion
    if(document.getElementById('TipoDeHabitacion').innerHTML == "Acomodacion: Habitacion Sencilla"){
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + (parseInt(document.getElementById('Tarifa').innerHTML) * 2) + "$COP";   
        TotalAPagar = (((parseInt(document.getElementById('Tarifa').innerHTML)*2)*cantidad_Habitaciones_Sencillas) + ((parseInt(document.getElementById('Tarifa').innerHTML)*4)*cantidad_Habitaciones_Dobles) + ((parseInt(document.getElementById('Tarifa').innerHTML)*6)*cantidad_Habitaciones_Triples) +(parseInt(document.getElementById('Tarifa').innerHTML) * 2)+TotalNinos+TotalInfantes); 
    }else if(document.getElementById('TipoDeHabitacion').innerHTML == "Acomodacion: Habitacion Doble"){
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + (parseInt(document.getElementById('Tarifa').innerHTML) * 4) + "$COP";        
        TotalAPagar = (((parseInt(document.getElementById('Tarifa').innerHTML)*2)*cantidad_Habitaciones_Sencillas) + ((parseInt(document.getElementById('Tarifa').innerHTML)*4)*cantidad_Habitaciones_Dobles) + ((parseInt(document.getElementById('Tarifa').innerHTML)*6)*cantidad_Habitaciones_Triples) +(parseInt(document.getElementById('Tarifa').innerHTML) * 4)+TotalNinos+TotalInfantes);
    }else if(document.getElementById('TipoDeHabitacion').innerHTML == "Acomodacion: Habitacion Triple"){
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + (parseInt(document.getElementById('Tarifa').innerHTML) * 6) + "$COP";    
        TotalAPagar = (((parseInt(document.getElementById('Tarifa').innerHTML)*2)*cantidad_Habitaciones_Sencillas) + ((parseInt(document.getElementById('Tarifa').innerHTML)*4)*cantidad_Habitaciones_Dobles) + ((parseInt(document.getElementById('Tarifa').innerHTML)*6)*cantidad_Habitaciones_Triples) +(parseInt(document.getElementById('Tarifa').innerHTML) * 6)+TotalNinos+TotalInfantes);
    }else{
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: N/A";    
    }   

    // ----------------------------------------------------------------------
    // Se crea una funcion click para que se enfoque en el boton de agregar habitaciones sencillas y en el input
    // De paso una condicion que determine un limite de cuantas habitaciones sencillas se pueden poner
    // Si se ejecuta de manera exitosa, se abrira la ventana de adicciones asi como se desabilitaran algunos botones
    
    $('#AgregarNumeroDeHabitacionesSencillas').on('click', function(e) { 
        cantidad_Habitaciones_Sencillas = $("#NumeroDeHabitacionesSencillas").val();
        if(cantidad_Habitaciones_Sencillas < 1 || cantidad_Habitaciones_Sencillas > 3){
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Ingresar Un Numero Valido",
              });  
        }else{
            document.getElementById("AgregarNumeroDeHabitacionesSencillas").disabled = true;
            document.getElementById("NumeroDeHabitacionesSencillas").disabled = true;
            $(".BloqueContenido__SeparadorHabitacionSencilla").toggle();
        }
    }); 

    // ----------------------------------------------------------------------
    // Se crea una funcion click para eliminar las adicciones que el usuario quiera eliminar

    $('#EliminarSencilla').on('click', function(e) { 
        Swal.fire({
            title: "Confirmar",
            text: "Deseas eliminar la adiccion?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Si"
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire({
                title: "Eliminado",
                text: "La Adiccion a sido eliminada.",
                icon: "success"
              });
                document.getElementById("AgregarNumeroDeHabitacionesSencillas").disabled = false;
                document.getElementById("NumeroDeHabitacionesSencillas").disabled = false;
                document.getElementById("BotonAgregarNinos").disabled = false;
                document.getElementById("CantidadDeNinos").disabled = false;
                document.getElementById("EliminarSencilla").disabled = true;
                document.getElementById("CantidadDeInfantes").disabled = false;
                document.getElementById("BotonAgregarInfantes").disabled = false;
                document.getElementById("NumeroDeHabitacionesSencillas").value = "";   
                document.getElementById("BotonAdiccion").disabled = false;

                TotalAPagar = TotalAPagar - (parseInt(document.getElementById('Tarifa').innerHTML)*2)*cantidad_Habitaciones_Sencillas - TotalNinos - TotalInfantes;
                document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";

                AcumuladorHabitacionSencilla = 0;
                cantidad_Habitaciones_Sencillas = 0;
                ControladorContenidoSencillo = 0;
                TotalNinos = TotalNinos - (parseInt(($("#CantidadDeNinos").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.75));
                TotalInfantes = TotalInfantes - (parseInt(($("#CantidadDeInfantes").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.10));
                document.getElementById("CantidadDeInfantes").value = "";  
                document.getElementById("CantidadDeNinos").value = ""; 
                $(".BloqueContenido__SeparadorHabitacionSencilla").toggle();
            }
          });
    }); 

    // ----------------------------------------------------------------------

    $('#AgregarNumeroDeHabitacionesDobles').on('click', function(e) { 
        cantidad_Habitaciones_Dobles = $("#NumeroDeHabitacionesDobles").val();
        if(cantidad_Habitaciones_Dobles < 1 || cantidad_Habitaciones_Dobles > 3){
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Ingresar Un Numero Valido",
              });  
        }else{
            document.getElementById("AgregarNumeroDeHabitacionesDobles").disabled = true;
            document.getElementById("NumeroDeHabitacionesDobles").disabled = true;
            $(".BloqueContenido__SeparadorHabitacionDoble").toggle();
        }
    }); 

    // ----------------------------------------------------------------------

    $('#EliminarDoble').on('click', function(e) { 
        Swal.fire({
            title: "Confirmar",
            text: "Deseas eliminar la adiccion?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Si"
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire({
                title: "Eliminado",
                text: "La Adiccion a sido eliminada.",
                icon: "success"
              });
                document.getElementById("AgregarNumeroDeHabitacionesDobles").disabled = false;
                document.getElementById("NumeroDeHabitacionesDobles").disabled = false;
                document.getElementById("BotonAgregarNinosDobles").disabled = false;
                document.getElementById("CantidadDeNinosDobles").disabled = false;
                document.getElementById("EliminarDoble").disabled = true;
                document.getElementById("CantidadDeInfantesDobles").disabled = false;
                document.getElementById("BotonAgregarInfantesDobles").disabled = false;
                document.getElementById("NumeroDeHabitacionesDobles").value = "";   
                document.getElementById("BotonAdiccionDoble").disabled = false;

                TotalAPagar = TotalAPagar - (parseInt(document.getElementById('Tarifa').innerHTML)*4)*cantidad_Habitaciones_Dobles - TotalNinos - TotalInfantes;
                document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";

                AcumuladorHabitacionDoble = 0;
                cantidad_Habitaciones_Dobles = 0;
                ControladorContenidoDoble = 0;
                TotalNinos = TotalNinos - (parseInt(($("#CantidadDeNinosDobles").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.75));
                TotalInfantes = TotalInfantes - (parseInt(($("#CantidadDeInfantesDobles").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.10));
                document.getElementById("CantidadDeInfantesDobles").value = "";  
                document.getElementById("CantidadDeNinosDobles").value = ""; 
                $(".BloqueContenido__SeparadorHabitacionDoble").toggle(); 


            }
          });
    }); 

    // ----------------------------------------------------------------------

    $('#AgregarNumeroDeHabitacionesTriples').on('click', function(e) { 
        cantidad_Habitaciones_Triples = $("#NumeroDeHabitacionesTriples").val();
        if(cantidad_Habitaciones_Triples < 1 || cantidad_Habitaciones_Triples > 3){
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Ingresar Un Numero Valido",
              });  
        }else{
            document.getElementById("AgregarNumeroDeHabitacionesTriples").disabled = true;
            document.getElementById("NumeroDeHabitacionesTriples").disabled = true;
            $(".BloqueContenido__SeparadorHabitacionTriples").toggle();
        }
    }); 

    // ----------------------------------------------------------------------

    $('#EliminarTriple').on('click', function(e) { 
        Swal.fire({
            title: "Confirmar",
            text: "Deseas eliminar la adiccion?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Si"
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire({
                title: "Eliminado",
                text: "La Adiccion a sido eliminada.",
                icon: "success"
              });
                document.getElementById("AgregarNumeroDeHabitacionesTriples").disabled = false;
                document.getElementById("NumeroDeHabitacionesTriples").disabled = false;
                document.getElementById("BotonAgregarNinosTriples").disabled = false;
                document.getElementById("CantidadDeNinosTriples").disabled = false;
                document.getElementById("EliminarTriple").disabled = true;
                document.getElementById("CantidadDeInfantesTriples").disabled = false;
                document.getElementById("BotonAgregarInfantesTriples").disabled = false;
                document.getElementById("NumeroDeHabitacionesTriples").value = "";   
                document.getElementById("BotonAdiccionTriple").disabled = false;

                TotalAPagar = TotalAPagar - (parseInt(document.getElementById('Tarifa').innerHTML)*6)*cantidad_Habitaciones_Triples - TotalNinos - TotalInfantes;
                document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";

                AcumuladorHabitacionTriple = 0;
                cantidad_Habitaciones_Triples = 0;
                ControladorContenidoTriple = 0;
                TotalNinos = TotalNinos - (parseInt(($("#CantidadDeNinosTriples").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.75));
                TotalInfantes = TotalInfantes - (parseInt(($("#CantidadDeInfantesTriples").val()*parseInt(document.getElementById('Tarifa').innerHTML))*0.10));
                document.getElementById("CantidadDeInfantesTriples").value = "";  
                document.getElementById("CantidadDeNinosTriples").value = ""; 
                $(".BloqueContenido__SeparadorHabitacionTriples").toggle(); 


            }
          });
    }); 

    // ----------------------------------------------------------------------
    // Se crea una funcion click para enfocarse en el boton de agregar niños, haciendo sus respectivos calculos en el proceso
    // Y de paso estableciendo limites de cuantos niños se pueden añadir
    // Asi como desabilitando algunos botones en el proceso

    $('#BotonAgregarNinos').on('click', function(e) { 
        let cantidad_de_ninos = $("#CantidadDeNinos").val();
            if(cantidad_de_ninos <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_ninos > 2 || AcumuladorHabitacionSencilla >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionSencilla = AcumuladorHabitacionSencilla + parseInt(cantidad_de_ninos);
                    TotalNinos = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.75)*cantidad_de_ninos) + TotalNinos;
                    document.getElementById("CantidadDeNinos").disabled = true;
                    document.getElementById("BotonAgregarNinos").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------

    $('#BotonAgregarNinosDobles').on('click', function(e) { 
        let cantidad_de_ninos = $("#CantidadDeNinosDobles").val();
            if(cantidad_de_ninos <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_ninos > 2 || AcumuladorHabitacionDoble >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionDoble = AcumuladorHabitacionDoble + parseInt(cantidad_de_ninos);
                    TotalNinos = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.75)*cantidad_de_ninos) + TotalNinos;
                    document.getElementById("CantidadDeNinosDobles").disabled = true;
                    document.getElementById("BotonAgregarNinosDobles").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------

    $('#BotonAgregarNinosTriples').on('click', function(e) { 
        let cantidad_de_ninos = $("#CantidadDeNinosTriples").val();
            if(cantidad_de_ninos <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_ninos > 2 || AcumuladorHabitacionTriple >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionTriple = AcumuladorHabitacionTriple + parseInt(cantidad_de_ninos);
                    TotalNinos = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.75)*cantidad_de_ninos) + TotalNinos;
                    document.getElementById("CantidadDeNinosTriples").disabled = true;
                    document.getElementById("BotonAgregarNinosTriples").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------
    // Se crea una funcion click para enfocarse en el boton de agregar infantes, haciendo sus respectivos calculos en el proceso
    // Y de paso estableciendo limites de cuantos infantes se pueden añadir
    // Asi como desabilitando algunos botones en el proceso

    $('#BotonAgregarInfantes').on('click', function(e) { 
        let cantidad_de_infantes = $("#CantidadDeInfantes").val();
            if(cantidad_de_infantes <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_infantes > 2 || AcumuladorHabitacionSencilla >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionSencilla = AcumuladorHabitacionSencilla + parseInt(cantidad_de_infantes);
                    TotalInfantes = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.10)*cantidad_de_infantes) + TotalInfantes;
                    document.getElementById("CantidadDeInfantes").disabled = true;
                    document.getElementById("BotonAgregarInfantes").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------

    $('#BotonAgregarInfantesDobles').on('click', function(e) { 
        let cantidad_de_infantes = $("#CantidadDeInfantesDobles").val();
            if(cantidad_de_infantes <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_infantes > 2 || AcumuladorHabitacionDoble >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionDoble = AcumuladorHabitacionDoble + parseInt(cantidad_de_infantes);
                    TotalInfantes = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.10)*cantidad_de_infantes) + TotalInfantes;
                    document.getElementById("CantidadDeInfantesDobles").disabled = true;
                    document.getElementById("BotonAgregarInfantesDobles").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------

    $('#BotonAgregarInfantesTriples').on('click', function(e) { 
        let cantidad_de_infantes = $("#CantidadDeInfantesTriples").val();
            if(cantidad_de_infantes <= 0){
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Ingresar Un Numero Valido",
                });  
            }else{
                if(cantidad_de_infantes > 2 || AcumuladorHabitacionTriple >= 2){
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Excediendo el limite de ocupantes en la habitacion.",
                    });  
                }else{
                    AcumuladorHabitacionTriple = AcumuladorHabitacionTriple + parseInt(cantidad_de_infantes);
                    TotalInfantes = ((parseInt(parseInt(document.getElementById('Tarifa').innerHTML)) * 0.10)*cantidad_de_infantes) + TotalInfantes;
                    document.getElementById("CantidadDeInfantesTriples").disabled = true;
                    document.getElementById("BotonAgregarInfantesTriples").disabled = true;
                }
            }
    });

    // ----------------------------------------------------------------------
    // Se realiza un boton que desabilite los demas botones y los inputs a la hora de confirmar la adiccion de las reservas

    $('#BotonAdiccion').on('click', function(e) { 
        document.getElementById("EliminarSencilla").disabled = false;
        document.getElementById("CantidadDeInfantes").disabled = true;
        document.getElementById("CantidadDeNinos").disabled = true;
        document.getElementById("BotonAgregarInfantes").disabled = true;
        document.getElementById("BotonAgregarNinos").disabled = true;
        document.getElementById("BotonAdiccion").disabled = true;

        TotalAPagar = (parseInt(document.getElementById('Tarifa').innerHTML)*2)*cantidad_Habitaciones_Sencillas + TotalInfantes + TotalNinos + TotalAPagar;
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";
    });

    // ----------------------------------------------------------------------

    $('#BotonAdiccionDoble').on('click', function(e) { 
        document.getElementById("EliminarDoble").disabled = false;
        document.getElementById("CantidadDeInfantesDobles").disabled = true;
        document.getElementById("CantidadDeNinosDobles").disabled = true;
        document.getElementById("BotonAgregarInfantesDobles").disabled = true;
        document.getElementById("BotonAgregarNinosDobles").disabled = true;
        document.getElementById("BotonAdiccionDoble").disabled = true;

        TotalAPagar = (parseInt(document.getElementById('Tarifa').innerHTML)*4)*cantidad_Habitaciones_Dobles + TotalInfantes + TotalNinos + TotalAPagar;
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";
    });

    // ----------------------------------------------------------------------

    $('#BotonAdiccionTriple').on('click', function(e) { 
        document.getElementById("EliminarTriple").disabled = false;
        document.getElementById("CantidadDeInfantesTriples").disabled = true;
        document.getElementById("CantidadDeNinosTriples").disabled = true;
        document.getElementById("BotonAgregarInfantesTriples").disabled = true;
        document.getElementById("BotonAgregarNinosTriples").disabled = true;
        document.getElementById("BotonAdiccionTriple").disabled = true;

        TotalAPagar = (parseInt(document.getElementById('Tarifa').innerHTML)*6)*cantidad_Habitaciones_Triples + TotalInfantes + TotalNinos + TotalAPagar;
        document.getElementById("ValorAPagar").textContent="Valor A Pagar: " + TotalAPagar + "$COP";
    });
})