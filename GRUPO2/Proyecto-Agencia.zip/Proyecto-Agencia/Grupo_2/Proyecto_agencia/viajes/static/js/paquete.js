$(document).ready(function () {

    $(document).on("input",
        "input[id^='id_hospedajeacomodacion_set-'][id$='-tarifa_agencia']",
            function() {
                let tarifa_agencia = $(this);
                let id = tarifa_agencia.attr("id").match(/\d+/);
                let tarifa_hospedaje = $(
                    "#id_hospedajeacomodacion_set-" + id + "-tarifa"
                );
                let tarifa = tarifa_agencia.val();
                tarifa_hospedaje.val((tarifa * 1.2).toFixed(1));
            }
    );

    $(document).on(
      "change",
      "select[id^='id_paquetetour_set-'][id$='-hospedaje']",
      function () {
        let hospedajeId = $(this).val();
        let id = $(this).attr("id").match(/\d+/);
        let acomodacion = $("#id_paquetetour_set-" + id + "-id_hospedaje_acomodacion");
        let tarifa = $("#id_paquetetour_set-" + id + "-tarifa");
        if (hospedajeId) {
          $.ajax({
            url: "/acomodacion",
            // url: "/hospedaje",
            data: {
              q: hospedajeId,
            },
            dataType: "json",
            success: function (data) {
              console.log(data);
              tarifa.empty();     
              const opciones = data.map(
                (valor) =>
                  `<option value="${valor.id_hospedaje_acomodacion}">
                      ${valor.id_acomodacion__nombre}
                  </option>`
              );
  
              // Actualizamos el contenido en un solo paso para evitar múltiples manipulaciones del DOM
              acomodacion
                .empty()
                .append("<option>Seleccione una acomodación</option>")
                .append(opciones);
            },
          });
        }
      }
    );

    $(document).on(
      "change",
      "select[id^='id_paquetetour_set-'][id$='-id_hospedaje_acomodacion']",
      function () {
        let acomodacionId = $(this).val();
        let id = $(this).attr("id").match(/\d+/);
        let tarifa = $("#id_paquetetour_set-" + id + "-tarifa");
        if (acomodacionId) {
          $.ajax({
            url: "/tarifa_hospedaje_acomodacion",
            data: {
              q: acomodacionId,
            },
            dataType: "json",
            success: function (data) {
              // Asignar valor al input de tarifa
              tarifa.val(data[0].tarifa);
            },
            error: function (xhr, status, error) {
              console.error("Error:", error);
            },
          });
        }
      }
    );
})