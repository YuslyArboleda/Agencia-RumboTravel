from django.shortcuts import render
from django.db import connection
from django.http import JsonResponse
from django.core.paginator import PageNotAnInteger, Paginator, EmptyPage
from .models import (Acomodacion,
                     Adicion,
                     Cliente,
                     Destino,
                     DetalleReserva,
                     Hospedaje,
                     HospedajeAcomodacion,
                     Paquete,
                     PaqueteTour,
                     Reserva)

from .serializers import (AcomodacionSerializer,
                            AdicionSerializer,
                            ClienteSerializer,
                            DestinoSerializer,
                            DetalleReservaSerializer,
                            HospedajeSerializer,
                            HospedajeAcomodacionSerializer,
                            PaqueteSerializer,
                            PaqueteTourSerializer,
                            ReservaSerializer)

from rest_framework import viewsets
class AcomodacionViewSet(viewsets.ModelViewSet):
    queryset = Acomodacion.objects.all()
    serializer_class = AcomodacionSerializer

from rest_framework import viewsets
class AdicionViewSet(viewsets.ModelViewSet):
    queryset = Adicion.objects.all()
    serializer_class = AdicionSerializer

from rest_framework import viewsets
class ClienteViewSet(viewsets.ModelViewSet):
    queryset = Cliente.objects.all()
    serializer_class = ClienteSerializer

from rest_framework import viewsets
class DestinoViewSet(viewsets.ModelViewSet):
    queryset = Destino.objects.all()
    serializer_class = DestinoSerializer

from rest_framework import viewsets
class DetalleReservaViewSet(viewsets.ModelViewSet):
    queryset = DetalleReserva.objects.all()
    serializer_class = DetalleReservaSerializer

from rest_framework import viewsets
class HospedajeViewSet(viewsets.ModelViewSet):
    queryset = Hospedaje.objects.all()
    serializer_class = HospedajeSerializer

from rest_framework import viewsets
class HospedajeAcomodacionViewSet(viewsets.ModelViewSet):
    queryset = HospedajeAcomodacion.objects.all()
    serializer_class = HospedajeAcomodacionSerializer

from rest_framework import viewsets
class PaqueteViewSet(viewsets.ModelViewSet):
    queryset = Paquete.objects.all()
    serializer_class = PaqueteSerializer

from rest_framework import viewsets
class PaqueteTourViewSet(viewsets.ModelViewSet):
    queryset = PaqueteTour.objects.all()
    serializer_class = PaqueteTourSerializer

from rest_framework import viewsets
class ReservaViewSet(viewsets.ModelViewSet):
    queryset = Reserva.objects.all()
    serializer_class = ReservaSerializer

def index(request):
    return render(request, 'index.html')    

def buscar_destino(request):
    query = request.GET.get("q","")
    if query:
        with connection.cursor() as cursor:
            cursor.callproc("consultar_viajes_destino", [query])
            resultados = cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            resultado_dict = [dict(zip(columns, row)) for row in resultados]
        return JsonResponse (resultado_dict, safe=False)            
    return JsonResponse([], safe=False)

def buscar_paquetes(request): #Se crea un metodo de nombre buscar paquetes, y que pida un parametro para funcionar
    query = request.GET.get("q", "") #Se crea una variable de nombre query, para que se haga la consultaa la base de datos
    page = request.GET.get("page", 1) #Se crea una variable de nombre page, donde se establece el numero de la pagina por defecto
    print("Ingresó a la consulta") 
    print(f"Query recibido: {query}")
    resultado_dict = [] #Se crea una variable de nombre resultado_dict, en donde se almacenara informacion

    if query: #Se crea una condicion en donde el resultado de verdad es el que esta conformado por la paginacion y la consulta a la base de datos
        try: #Se crea un try el cual se conectara a la base de datos, cumpliendo la funcion de redirigir al usuario a la pagina en donde estan los paquetes
            with connection.cursor() as cursor: #Se hace una conexion a la base de dato para hacer una consulta
                cursor.callproc("consultar_paquete_tour", [query]) #Se llama al procedimiento consultar paquete tour de la base de datos, y se trae el valor que el usuario ingreso
                resultados = cursor.fetchall() #Se crea una variable de nombre resultados, este obtendra toda la informacion de la consulta y la almacenara en la variable
                columns = [col[0] for col in cursor.description] #Se crea una variable de nombre columnas, donde le aplicara columnas a la descripcion 
                resultado_dict = [dict(zip(columns, row)) for row in resultados] #Se almacena toda la informacion de la consulta en la variable
                paginator = Paginator(resultado_dict, 2)  #Se crea una variable de nombre paginator que agarra la informacion de la variable resultado_dict, y los organiza en distintas secciones, el numero 2 indicando la cantidad de secciones que se van a mostrar por pagina
                
                try: 
                    paquetes = paginator.page(page)
                except PageNotAnInteger:
                    paquetes = paginator.page(1)
                except EmptyPage:
                    paquetes = paginator.page(paginator.num_pages)
                return render(
                    request,
                        "HTML/Paquete.html",
                    {
                        "resultados": paquetes,
                        "query": query,
                    },
                )

        except Exception as e: #En caso de que no se cumpla el try y no todo salga como lo esperado, se genera un exception donde nos diga cual fue el error que ocurrio
            # Agregar depuración para el error
            print(f"Error al ejecutar el procedimiento almacenado: {e}")
            return JsonResponse({"error": str(e)}, status=500)
    else: #En caso de que la condicion no se cumpla, renderizara la pagina usando el parametro obtenido, solamente que no traera ningun resultado al no haber recibido nada
        return render(request, "HTML/Paquete.html", {"resultados": []})
    
def detalle_paquete(request): #Es la misma premisa como buscar paquetes solamente que no tiene paginacion y redirecciona a otro HTML, asi como tiene otro procedimiento
    query = request.GET.get("q", "")
    print("Ingresó a la consulta")
    print(f"Query recibido: {query}")
    resultado_dict = []

    if query:
        try:
            with connection.cursor() as cursor:
                cursor.callproc("consultar_detallepaquetetour", [query])
                resultados = cursor.fetchall()
                columns = [col[0] for col in cursor.description]
                resultado_dict = [dict(zip(columns, row)) for row in resultados]

                return render(
                    request,
                    "HTML/Detalle_Paquete.html",
                    {
                        "resultados": resultado_dict,
                        "query": query,
                    },
                )
        except Exception as e:
            # Agregar depuración para el error
            print(f"Error al ejecutar el procedimiento almacenado: {e}")
            return JsonResponse({"error": str(e)}, status=500)
    else:
        return render(request, "HTML/Detalle_Paquete.html", {"resultados": []})
    
def tarifa_hospedaje_acomodacion(request):
    query = request.GET.get("q")
    try:
        acomodaciones = HospedajeAcomodacion.objects.filter(
            id_hospedaje_acomodacion=query
        ).values("id_acomodacion", "tarifa")
        return JsonResponse(list(acomodaciones), safe=False)
    except Exception as e:
        print(f"Error: {str(e)}")  # Log del error para depuración
        return JsonResponse({"error": "Error interno del servidor"}, status=500)
    
def acomodacion(request):
    query = request.GET.get("q")
    print(query)
    try:
        acomodaciones = HospedajeAcomodacion.objects.filter(
            id_hospedaje=query
        ).values("id_hospedaje_acomodacion", "tarifa", "id_acomodacion__nombre")
        return JsonResponse(list(acomodaciones), safe=False)
    except Exception as e:
        print(f"Error: {str(e)}")  # Log del error para depuración
        return JsonResponse({"error": "Error interno del servidor"}, status=500)
    
def registro(request):
    return render(request, 'HTML/Usuario.html')  

def recibo(request):
    return render(request, 'HTML/Recibo.html')  