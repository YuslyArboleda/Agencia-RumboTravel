from django.db import models
class Acomodacion(models.Model):
    id_acomodacion = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=300)
    descripcion = models.TextField()
    estado = models.IntegerField()
    capacidad = models.IntegerField()
    def __str__(self):
        return self.nombre

class Adicion(models.Model):
    id_adicion = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=20)
    descripcion = models.TextField()
    costo = models.FloatField()
    estado = models.IntegerField()
    def __str__(self):
        return self.nombre

class Cliente(models.Model):
    id_cliente = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=200)
    tipo_doc = models.CharField(max_length=20)
    documento = models.CharField(unique=True, max_length=20)
    telefono = models.CharField(max_length=20)
    correo = models.CharField(max_length=200)
    direccion = models.CharField(max_length=50)
    id_destino = models.ForeignKey('Destino', models.PROTECT, db_column='id_destino')
    estado = models.IntegerField()

    def __str__(self):
        return self.nombre


class Destino(models.Model):
    id_destino = models.AutoField(primary_key=True)
    destino = models.CharField(max_length=200)
    estado = models.IntegerField()

    def __str__(self):
        return self.destino


class DetalleReserva(models.Model):
    id_detalle_reserva = models.AutoField(primary_key=True)
    id_reserva = models.ForeignKey('Reserva', models.PROTECT, db_column='id_reserva')
    id_paquete_tour = models.ForeignKey('PaqueteTour', models.PROTECT, db_column='id_paquete_tour', blank=True, null=True)
    id_acomodacion = models.ForeignKey(Acomodacion, models.PROTECT, db_column='id_acomodacion', blank=True, null=True)
    id_adicion = models.ForeignKey(Adicion, models.PROTECT, db_column='id_adicion', blank=True, null=True)
    habitaciones = models.IntegerField()
    adulto = models.IntegerField()
    infante = models.IntegerField()
    comentarios = models.CharField(max_length=500, blank=True, null=True)

class Hospedaje(models.Model):
    id_hospedaje = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    direccion = models.CharField(max_length=50)
    correo = models.CharField(max_length=30)
    tipo_hospedaje = models.CharField(max_length=30)
    descripcion = models.TextField()
    telefono = models.CharField(max_length=50)
    tarifa_base = models.FloatField()
    id_destino = models.ForeignKey(Destino, models.PROTECT, db_column='id_destino')
    estado = models.IntegerField()
    imagen = models.ImageField(upload_to="assets/img",blank=True, null=True)

    def __str__(self):
        return self.nombre


class HospedajeAcomodacion(models.Model):
    id_hospedaje_acomodacion = models.AutoField(primary_key=True)
    id_acomodacion = models.ForeignKey(Acomodacion, models.PROTECT, db_column='id_acomodacion')
    id_hospedaje = models.ForeignKey(Hospedaje, models.PROTECT, db_column='id_hospedaje')
    temporada = models.CharField(max_length=20)
    tarifa_agencia = models.FloatField()
    tarifa = models.FloatField()
    imagen = models.ImageField(upload_to="assets/img",blank=True, null=True)
    def __str__(self):
        return f"{self.id_acomodacion} en {self.id_hospedaje} - Temporada: {self.temporada}"

class Paquete(models.Model):
    id_paquete = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    vigencia_inicio = models.DateField()
    vigencia_fin = models.DateField()
    noche = models.IntegerField()
    incluye = models.CharField(max_length=200)
    no_incluye = models.CharField(max_length=200)
    costo = models.FloatField()
    disponibilidad = models.CharField(max_length=50)
    Nombre_Tour = models.CharField(max_length=50)
    Descripcion_Tour = models.TextField(blank=True, null=True)
    valor_Tour = models.FloatField(blank= True, null= True)
    duracion_Tour = models.IntegerField()
    imagen = models.ImageField(upload_to="assets/img",blank=True, null=True)
    estado = models.IntegerField()

    def __str__(self):
        return self.nombre


class PaqueteTour(models.Model):
    id_paquete_tour = models.AutoField(primary_key=True)
    id_hospedaje_acomodacion = models.ForeignKey('HospedajeAcomodacion', models.PROTECT, db_column='id_hospedaje_acomodacion')
    id_paquete = models.ForeignKey(Paquete, models.PROTECT, db_column='id_paquete')

class Reserva(models.Model):
    id_reserva = models.AutoField(primary_key=True)
    fecha = models.DateField()
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    cantidad = models.IntegerField()
    total = models.FloatField()
    estado_reserva = models.CharField(max_length=20)
    metodo_pago = models.CharField(max_length=20)
    id_cliente = models.ForeignKey('Cliente', models.PROTECT, db_column='id_cliente')
    estado = models.IntegerField()
    
    def __str__(self):
        return f"Fecha: {self.fecha} | Fecha Inicio:  {self.fecha_inicio} | Fecha Fin: {self.fecha_fin} | Cantidad: {self.cantidad} | Total: {self.total} | Metodo De Pago: {self.metodo_pago} | Cliente: {self.id_cliente}"


