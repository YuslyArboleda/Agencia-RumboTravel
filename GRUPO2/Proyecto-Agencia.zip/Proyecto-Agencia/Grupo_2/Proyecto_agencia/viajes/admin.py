from django.contrib import admin
from .forms import PaqueteTourForm
from .models import (
    Acomodacion,
    Reserva,
    Cliente,
    Destino,
    Hospedaje,
    HospedajeAcomodacion,
    Paquete,
    PaqueteTour,
    Adicion,
    DetalleReserva,
)

class BaseAdmin(admin.ModelAdmin):
    class Media:
        js = ("js/jquery-3.7.1.min.js","js/paquete.js")

class HospedajeAcomodacionInLine(admin.TabularInline):
    model = HospedajeAcomodacion
    extra = 1

class PaqueteTourInLine(admin.TabularInline):
    model = PaqueteTour
    form=PaqueteTourForm
    extra = 1

class PaqueteTourAdmin(BaseAdmin):
    inlines = [PaqueteTourInLine]
    search_fields = [
        "nombre", "vigencia_inicio", "vigencia_fin", "noche", "incluye", "no_incluye", "costo", "disponibilidad", "Nombre_Tour", "duracion_Tour", "valor_Tour", "estado"
    ]
    list_display = [
        "nombre", "vigencia_inicio", "vigencia_fin", "noche", "incluye", "no_incluye", "costo", "disponibilidad", "Nombre_Tour", "duracion_Tour", "valor_Tour", "estado"
    ]

class HospedajeAdmin(BaseAdmin):
    inlines = [HospedajeAcomodacionInLine]
    search_fields = [
        "nombre", "direccion", "correo", "descripcion", "telefono", "tipo_hospedaje", "tarifa_base", "estado"
    ]
    list_display = [
        "nombre", "direccion", "correo", "descripcion", "telefono", "tipo_hospedaje", "tarifa_base", "estado"
    ]

class AcomodacionAdmin(BaseAdmin):
    search_fields = [
        "nombre", "descripcion", "estado"
    ]
    list_display = [
        "nombre", "descripcion", "estado"
    ]

class AdicionAdmin(BaseAdmin):
    search_fields = [
        "nombre", "descripcion", "costo", "estado"
    ]
    list_display = [
        "nombre", "descripcion", "costo", "estado"
    ]

class ClientenAdmin(BaseAdmin):
    search_fields = [
        "nombre", "tipo_doc", "documento", "telefono", "correo", "direccion", "id_destino", "estado"
    ]
    list_display = [
        "nombre", "tipo_doc", "documento", "telefono", "correo", "direccion", "id_destino", "estado"
    ]

class DestinoAdmin(BaseAdmin):
    search_fields = [
        "destino", "estado"
    ]
    list_display = [
        "destino", "estado"
    ]

class ReservaAdmin(BaseAdmin):
    search_fields = [
        "fecha", "fecha_inicio", "fecha_fin", "cantidad", "total", "metodo_pago", "id_cliente", "estado"
    ]
    list_display = [
        "fecha", "fecha_inicio", "fecha_fin", "cantidad", "total", "metodo_pago", "id_cliente", "estado"
    ]

admin.site.register(Acomodacion, AcomodacionAdmin)
admin.site.register(Hospedaje, HospedajeAdmin)
admin.site.register(Reserva, ReservaAdmin)
admin.site.register(Cliente, ClientenAdmin)
admin.site.register(Destino, DestinoAdmin)
admin.site.register(DetalleReserva, BaseAdmin)
admin.site.register(Adicion, AdicionAdmin)
admin.site.register(Paquete, PaqueteTourAdmin)